
// Search the bookmarks when entering the search keyword.
$(function() {
  var query='';
  
  $('#search').keyup(function() {
      $('#bookmarks').empty();
      query = $('#search').val();

      //dumpBookmarks($('#search').val());
      chrome.bookmarks.search(query, function (results){
        var total = results.length;
        $('#total').html(total+' urls');
        if(total>0){
          var html = new Array();
          for(i=0; i<total ;i++){
            var node = results[i];
            var className = (node.children) ? 'folder':'link';
            if(className=='folder'){
              str = '<li class="'+className+'">'+node.title + ' ['+ node.url +']</li>';
            }else{
              // !todo: handle bookmarklets correctly
              str = '<li class="'+className+'"><a href="'+ node.url +'" class="bookmark">'+node.title + '</a></li>';
            }
            
            html.push(str);
          }
          $('#bookmarks').html('<ol id="bookmarkslist">'+html.join('')+'</ol>');
        }else{
          $('#bookmarks').html('<p style="text-align:center">Sorry, no result.</p>');
        }
     });

  });
  $(document).on('click', 'a.bookmark', function(){
      chrome.tabs.create({url: $(this).attr('href')});
  });
});
function strip_tags(str){
  return str.replace(/(<([^>]+)>)/ig,"");
}